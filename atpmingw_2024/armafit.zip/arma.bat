@echo off
@if %1. == . goto help
@if %2. == . armafit %1.aft -d1 -g%1.agf
@copy TEMP.PCH %1.pch
@find "FAILED" %1.pch
@find "UNSTABLE" %1.pch
@if %2. == . goto end
@armafit %1.aft -d1 -g%1 -s%2
@copy TEMP.PCH %1.pch
@find "FAILED" %1.pch
@find "UNSTABLE" %1.pch
@goto end
:help
@echo
@echo usage:
@echo arma file [max time in seconds]
@echo file must be a .aft file
@echo but .aft must be not passed
@echo
:end
